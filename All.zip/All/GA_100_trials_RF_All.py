import os
import math
import pickle
import random
import numpy as np
import pandas as pd
from numpy import std
from numpy import mean

from matplotlib import pyplot
import matplotlib.pyplot as plt

from sklearn.model_selection import KFold
from sklearn.metrics import mean_absolute_error
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import RepeatedKFold
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import cross_val_score
from genetic_selection import GeneticSelectionCV as GA

train = pd.read_csv('train_data.csv')
test = pd.read_csv('test_data.csv')
origin = pd.read_csv('origin.csv')
origin_TDM = pd.read_csv('5_TDM_origin.csv')
origin_CON = pd.read_csv('5_CON_origin.csv')

train_X = train.drop(columns = ['rno', 'Visite_day', 'Randomization group (1_TDM 2_Control)', 'dead', 'Sofa'])
train_y = train[['Sofa']]
train_pat = train[['rno', 'Visite_day', 'Randomization group (1_TDM 2_Control)', 'dead']]
test_X = test.drop(columns = ['rno', 'Visite_day', 'Randomization group (1_TDM 2_Control)', 'dead', 'Sofa'])
test_y = test[['Sofa']]
test_pat = test[['rno', 'Visite_day', 'Randomization group (1_TDM 2_Control)', 'dead']]
origin_X = origin.drop(columns = ['rno', 'Visite_day', 'Randomization group (1_TDM 2_Control)', 'dead', 'Sofa'])
origin_y = origin[['Sofa']]
origin_pat = origin[['rno', 'Visite_day', 'Randomization group (1_TDM 2_Control)', 'dead']]
originTDM_X = origin_TDM.drop(columns = ['rno', 'Visite_day', 'Randomization group (1_TDM 2_Control)', 'dead', 'Sofa'])
originTDM_y = origin_TDM[['Sofa']]
originTDM_pat = origin_TDM[['rno', 'Visite_day', 'Randomization group (1_TDM 2_Control)', 'dead']]
originCON_X = origin_CON.drop(columns = ['rno', 'Visite_day', 'Randomization group (1_TDM 2_Control)', 'dead', 'Sofa'])
originCON_y = origin_CON[['Sofa']]
originCON_pat = origin_CON[['rno', 'Visite_day', 'Randomization group (1_TDM 2_Control)', 'dead']]

X = train_X
y = train_y
y = y.astype('float')
estimator = RandomForestRegressor()
# evaluate the models and store results
results = []
names = []
kf = KFold(n_splits=10, shuffle=True, random_state=1)
for i in range(1, len(train_X.columns) + 1):
    model = GA(estimator, cv=5, verbose=1, scoring='neg_mean_absolute_error', max_features=i, n_population=165,
               crossover_proba=0.5, mutation_proba=0.05, n_generations=100, crossover_independent_proba=0.5,
               mutation_independent_proba=0.04, tournament_size=3, n_gen_no_change=10, caching=True, n_jobs=-1)
    model = model.fit(X, y)
    X_selection = X[X.columns[model.support_].tolist()]
    cv = RepeatedKFold(n_splits=10, n_repeats=3, random_state=1)
    scores = cross_val_score(RandomForestRegressor(), X_selection, y, scoring='neg_mean_absolute_error', cv=cv, n_jobs=-1, error_score='raise')
    results.append(scores)
    names.append(i)
    print('>%s %.3f (%.3f)' % (i, mean(scores), std(scores)))
# plot model performance for comparison
pyplot.figure(figsize =(12, 9))
pyplot.boxplot(results, labels=names, showmeans=True)
pyplot.xticks(rotation=45)
pyplot.savefig('box_plot.png')
