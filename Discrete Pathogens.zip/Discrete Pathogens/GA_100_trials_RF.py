import os
import math
import pickle
import random
import numpy as np
import pandas as pd
from numpy import std
from numpy import mean

from matplotlib import pyplot
import matplotlib.pyplot as plt

from sklearn.model_selection import KFold
from sklearn.metrics import mean_absolute_error
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import RepeatedKFold
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import cross_val_score
from genetic_selection import GeneticSelectionCV as GA

train = pd.read_csv('train_data.csv')
test = pd.read_csv('test_data.csv')
origin = pd.read_csv('origin.csv')
origin_TDM = pd.read_csv('5_TDM_origin.csv')
origin_CON = pd.read_csv('5_CON_origin.csv')

con_cols = pd.read_csv('pathogens.csv')
con_cols = con_cols.columns.tolist()
con_cols.extend(['Randomization group (1_TDM 2_Control)', 'dead', 'Sofa'])
con_cols.insert(0, 'Visite_day')
con_cols.insert(0, 'rno')

train = train[con_cols]
test = test[con_cols]
origin = origin[con_cols]
origin_TDM = origin_TDM[con_cols]
origin_CON = origin_CON[con_cols]

train_X = train.drop(columns = ['rno', 'Visite_day', 'Randomization group (1_TDM 2_Control)', 'dead', 'Sofa'])
train_y = train[['Sofa']]
train_pat = train[['rno', 'Visite_day', 'Randomization group (1_TDM 2_Control)', 'dead']]
test_X = test.drop(columns = ['rno', 'Visite_day', 'Randomization group (1_TDM 2_Control)', 'dead', 'Sofa'])
test_y = test[['Sofa']]
test_pat = test[['rno', 'Visite_day', 'Randomization group (1_TDM 2_Control)', 'dead']]
origin_X = origin.drop(columns = ['rno', 'Visite_day', 'Randomization group (1_TDM 2_Control)', 'dead', 'Sofa'])
origin_y = origin[['Sofa']]
origin_pat = origin[['rno', 'Visite_day', 'Randomization group (1_TDM 2_Control)', 'dead']]
originTDM_X = origin_TDM.drop(columns = ['rno', 'Visite_day', 'Randomization group (1_TDM 2_Control)', 'dead', 'Sofa'])
originTDM_y = origin_TDM[['Sofa']]
originTDM_pat = origin_TDM[['rno', 'Visite_day', 'Randomization group (1_TDM 2_Control)', 'dead']]
originCON_X = origin_CON.drop(columns = ['rno', 'Visite_day', 'Randomization group (1_TDM 2_Control)', 'dead', 'Sofa'])
originCON_y = origin_CON[['Sofa']]
originCON_pat = origin_CON[['rno', 'Visite_day', 'Randomization group (1_TDM 2_Control)', 'dead']]

X = train_X
y = train_y
y = y.astype('float')
estimator = RandomForestRegressor()
# evaluate the models and store results
features_saved = []
features_mean = []
features_std = []
n_features = 33
kf = KFold(n_splits=10, shuffle=True)
for i in range(1, 101):
    np.random.seed(None)
    model = GA(estimator, cv=5, verbose=1, scoring='neg_mean_absolute_error', max_features=n_features, n_population=165,
               crossover_proba=0.5, mutation_proba=0.05, n_generations=100, crossover_independent_proba=0.5,
               mutation_independent_proba=0.04, tournament_size=3, n_gen_no_change=10, caching=True, n_jobs=-1)
    model = model.fit(X, y)
    X_selection = X[X.columns[model.support_].tolist()]
    cv = RepeatedKFold(n_splits=10, n_repeats=3)
    scores = cross_val_score(RandomForestRegressor(), X_selection, y, scoring='neg_mean_absolute_error', cv=cv, n_jobs=-1, error_score='raise')
    features_saved.append(X_selection.columns)
    features_mean.append(mean(scores))
    features_std.append(std(scores))

fig = plt.figure(figsize=(10, 6))
plt.plot(range(len(features_mean)), features_mean)
plt.xlabel('Index')
plt.ylabel('Negative Mean Absolute Error')
plt.savefig('Negative_Mean_Absolute_Error.png')

counts = {string: 0 for string in train_X.columns.tolist()}
features_selected = []
for lst in features_saved:
    for string in lst:
        if string in counts:
            counts[string] += 1
            if counts[string] > 40 and string not in features_selected:
                features_selected.append(string)
fig = plt.figure(figsize=(10, 5))
ax = fig.add_subplot(1, 1, 1)
ax.bar(train_X.columns.tolist(), [counts[string] for string in train_X.columns.tolist()])
ax.set_xticklabels(train_X.columns.tolist(), rotation=90)
ax.set_xlabel('Feature')
ax.set_ylabel('Count')
plt.savefig('Histogram.png')

with open('features_saved.pickle', 'wb') as file:
    pickle.dump(features_saved, file)

with open('features_mean.pickle', 'wb') as file:
    pickle.dump(features_mean, file)

with open('features_std.pickle', 'wb') as file:
    pickle.dump(features_std, file)
