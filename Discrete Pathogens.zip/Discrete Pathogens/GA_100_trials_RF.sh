#!/bin/bash
#SBATCH --partition=single
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=20
#SBATCH --time=10:00:00
#SBATCH --output=%j.out

module list
module load devel/python/3.8

python3 -m pip install os --user
python3 -m pip install math --user
python3 -m pip install numpy --user
python3 -m pip install pickle --user
python3 -m pip install random --user
python3 -m pip install pandas --user
python3 -m pip install sklearn --user
python3 -m pip install matplotlib --user
python3 -m pip install sklearn-genetic --user

python3 -u GA_100_trials_RF.py
